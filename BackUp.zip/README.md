# FoundersKE
- **[FoundersKE*](https://founderske.vercel.app) - [Founders Kenya]**
<div align="center"; >

![footerlogo](https://user-images.githubusercontent.com/77758884/218035615-d07c3384-1123-4eb3-bb68-1e2a81431c0f.png)

</div>

- Empowers young entrepreneurs by providing mentorship and resources to turn their ideas into successful start-ups.
  
![image](https://github.com/FoundersKE/.github/assets/77758884/2341aef0-b997-4c3d-ba59-fdd8b5322cc2)

![image](https://github.com/FoundersKE/.github/assets/77758884/82031a67-d3df-414b-98a6-7a1640655b38)



- Visit [Our Home Page](https://founderske.vercel.app/) to learn more.
